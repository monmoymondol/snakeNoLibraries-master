#pragma once

#include <types.h>

namespace stringManipulation
{

	uint32_t strlen(const char *s);

};