#pragma once


//max is exclusive
int getRandomNumber(int min, int max);