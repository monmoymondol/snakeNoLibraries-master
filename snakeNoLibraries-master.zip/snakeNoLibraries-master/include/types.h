#pragma once

using int32_t = int;
using int64_t = long long int;
using uint32_t = unsigned int;
using uint64_t = unsigned long long int;