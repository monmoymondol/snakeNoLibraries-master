#pragma once

void consoleWrite(const char *c);